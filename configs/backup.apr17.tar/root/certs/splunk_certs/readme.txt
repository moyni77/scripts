indexer.pem
1) server cert
2) server private key
3) intermediate certificate
4) root CA Certificate
